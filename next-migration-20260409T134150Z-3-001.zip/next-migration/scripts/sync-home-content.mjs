import fs from "node:fs";
import path from "node:path";

const sourcePath = path.resolve(process.cwd(), "..", "web", "index.html");
const outputPath = path.resolve(process.cwd(), "content", "home-body.html");

const source = fs.readFileSync(sourcePath, "utf8");
const match = source.match(/(<div id="__next">[\s\S]*?)\n\s*<script id="__NEXT_DATA__"/);

if (!match) {
  throw new Error("Could not extract #__next content from web/index.html");
}

let bodyHtml = match[1];

fs.writeFileSync(outputPath, bodyHtml, "utf8");
console.log(`Synced: ${outputPath}`);
