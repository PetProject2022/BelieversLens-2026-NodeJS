import AnimationBootstrap from "./animation-bootstrap";
import { legalLinks } from "./legal-content";

const navigation = [
  { label: "Home", href: "#top" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Membership", href: "#membership" },
  { label: "Partners", href: "#partners" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

const trustStrip = [
  "Private.",
  "Family-centered.",
  "Built with dignity.",
  "Preventive health, thoughtfully organized.",
];

const whatWeDo = [
  {
    title: "Preventive Support",
    description:
      "We help people stay engaged earlier through structured, continuity-minded support designed to reduce avoidable gaps and missed warning signs.",
  },
  {
    title: "Health Summaries",
    description:
      "We organize important health information into clear, usable summaries that make it easier to communicate concerns, history, and next steps with confidence.",
  },
  {
    title: "Guided Follow-Through",
    description:
      "We help bring order to what happens between visits, referrals, recommendations, and ongoing care decisions.",
  },
  {
    title: "Family-Centered Coordination",
    description:
      "We design with households in mind, because health decisions are often shared, discussed, and carried by families, not individuals alone.",
  },
];

const differentiators = [
  "clarity over confusion",
  "continuity over fragmentation",
  "prevention over delay",
  "family-centered design over isolated decision-making",
  "dignity over cold process",
];

const steps = [
  {
    title: "Begin with a clear starting point",
    text: "You may enter through direct enrollment, a community event, a referral, or a care-related introduction.",
  },
  {
    title: "Bring structure to what matters",
    text: "We help organize key information, priorities, and relevant history in a way that is easier to understand and carry forward.",
  },
  {
    title: "Receive continuity-focused support",
    text: "Depending on your needs, this may include summaries, preventive follow-through, select monitoring support, or guided access to additional care pathways.",
  },
  {
    title: "Move forward with greater clarity",
    text: "The goal is not simply more information. It is better continuity, more confidence, and a more practical next step.",
  },
];

const membershipBenefits = [
  "preventive health support",
  "clear health summaries",
  "guided follow-through",
  "family-centered care support",
  "member-aligned access to select services and pathways",
];

const values = [
  {
    title: "Clarity",
    text: "People deserve plain language and better organization around their health.",
  },
  {
    title: "Continuity",
    text: "Support should not disappear between important moments.",
  },
  {
    title: "Dignity",
    text: "Every person deserves a respectful experience, never one that feels diminishing.",
  },
  {
    title: "Trust",
    text: "Health support should feel dependable, discreet, and worthy of confidence.",
  },
  {
    title: "Family-Centered Design",
    text: "Health is often lived across households, not in isolation.",
  },
  {
    title: "Thoughtful Access",
    text: "The best systems lower friction without lowering standards.",
  },
];

const libraryTiles = [
  {
    title: "Why continuity matters more than most people realize",
    text: "A closer look at what gets lost between visits, and why small gaps often become larger problems.",
  },
  {
    title: "What a clear health summary can change",
    text: "How better organization can improve communication, reduce stress, and support more informed care conversations.",
  },
  {
    title: "Health decisions rarely happen alone",
    text: "Why families, caregivers, and household dynamics shape more of the care experience than systems usually acknowledge.",
  },
  {
    title: "A more dignified standard for support",
    text: "Rethinking what respectful, privacy-conscious, and emotionally intelligent healthcare support should feel like.",
  },
];

export default function HomePage() {
  return (
    <>
      <main className="site-shell">
        <div className="page-aura" aria-hidden="true" />

        <div className="announcement-bar">
          <div className="container">
            <p>Thoughtful preventive support for individuals, families, and care partners.</p>
          </div>
        </div>

        <header className="site-header">
          <div className="container nav-row">
            <a className="brand" href="#top" aria-label="SovereignMD home">
              SovereignMD
            </a>

            <nav className="nav-links" aria-label="Primary">
              {navigation.map((item) => (
                <a key={item.label} href={item.href}>
                  {item.label}
                </a>
              ))}
            </nav>

            <a className="button button-secondary header-cta" href="#membership">
              Get Started
            </a>
          </div>
        </header>

        <section className="hero-section" id="top">
          <div className="container hero-grid">
            <div className="hero-copy">
              <p className="eyebrow reveal" data-reveal="up">
                Preventive health, thoughtfully organized
              </p>
              <h1 className="hero-title reveal" data-reveal="up" data-reveal-delay="120">
                A more thoughtful standard for staying ahead of your health.
              </h1>
              <p className="hero-body reveal" data-reveal="up" data-reveal-delay="220">
                SovereignMD helps individuals, families, and care partners stay better connected to health through
                preventive support, organized summaries, continuity-focused guidance, and carefully structured access
                pathways designed for real life.
              </p>

              <div className="hero-actions reveal" data-reveal="up" data-reveal-delay="320">
                <a className="button button-primary" href="#membership">
                  Get Started
                </a>
                <a className="button button-ghost" href="#how-it-works">
                  How It Works
                </a>
              </div>

              <p className="hero-note reveal" data-reveal="up" data-reveal-delay="420">
                A calmer, clearer way to move through healthcare.
              </p>
            </div>

            <div className="hero-visual reveal" data-reveal="zoom" data-reveal-delay="180">
              <div className="visual-orb orb-one" data-parallax="0.18" aria-hidden="true" />
              <div className="visual-orb orb-two" data-parallax="0.12" aria-hidden="true" />
              <div className="visual-card">
                <div className="visual-topline">
                  <span className="status-dot" aria-hidden="true" />
                  Private. Family-centered.
                </div>

                <div className="portrait-shell">
                  <div className="portrait-glow" aria-hidden="true" />
                  <div className="portrait-mask" aria-hidden="true">
                    <div className="portrait-gradient" />
                    <div className="portrait-leaf leaf-one" />
                    <div className="portrait-leaf leaf-two" />
                    <div className="portrait-leaf leaf-three" />
                  </div>
                </div>

                <div className="metric-chip chip-left" data-parallax="0.1">
                  <strong>Organized summaries</strong>
                  <span>Clearer health information people can actually carry forward.</span>
                </div>

                <div className="metric-chip chip-right" data-parallax="0.16">
                  <strong>Continuity-focused support</strong>
                  <span>Steadier follow-through between visits, referrals, and next steps.</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="trust-strip">
          <div className="container trust-row reveal" data-reveal="up">
            {trustStrip.map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
        </section>

        <section className="section" id="positioning">
          <div className="container">
            <div className="story-panel prose-panel reveal" data-reveal="up">
              <p className="eyebrow">Brand positioning</p>
              <h2>Healthcare often becomes harder than it should be.</h2>
              <p>
                Important details are forgotten. Records are scattered. Follow-through is inconsistent. Families are
                left trying to connect the dots while life keeps moving.
              </p>
              <p>
                SovereignMD was built to bring greater clarity, continuity, and steadiness to that experience. We
                support people earlier, help organize what matters, and create a more usable path forward across
                preventive care, care support, and select health service pathways.
              </p>
            </div>
          </div>
        </section>

        <section className="section" id="about">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">About SovereignMD</p>
              <h2>More connected, more understandable, and more human.</h2>
              <p>
                SovereignMD is a preventive health and care-support platform built to make healthcare feel more
                connected, more understandable, and more human.
              </p>
              <p>
                We created SovereignMD around a simple idea: people make better health decisions when they have
                clearer information, steadier support, and a more organized sense of what is happening over time.
              </p>
              <p>
                Our work is designed for those moments where the healthcare experience often begins to break down,
                when follow-up becomes fragmented, health history is difficult to communicate, or families are left
                carrying details that no system has meaningfully brought together.
              </p>
            </div>

            <div className="story-panel prose-panel reveal" data-reveal="right" data-reveal-delay="120">
              <p>
                That is where thoughtful structure matters. SovereignMD helps individuals and families navigate that
                complexity through preventive support, health summaries, continuity-focused guidance, and carefully
                designed service pathways that feel approachable rather than overwhelming.
              </p>
              <p>
                We are building for a higher standard, one where support feels calm, intelligent, respectful, and
                worthy of trust.
              </p>
            </div>
          </div>
        </section>

        <section className="section" id="stand-for">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">What We Stand For</p>
              <h2>Healthcare should do more than react.</h2>
              <p>It should help people stay organized before things become urgent.</p>
              <p>It should help families communicate more clearly.</p>
              <p>It should reduce friction instead of adding to it.</p>
              <p>
                And it should treat people with dignity whether they are seeking simple support or navigating more
                involved needs.
              </p>
              <p>
                Our mission is to make preventive and ongoing health support more understandable, more organized, and
                more humane.
              </p>
            </div>

            <div className="story-panel prose-panel reveal" data-reveal="right" data-reveal-delay="120">
              <p>
                Our vision is a healthcare experience that feels steadier from the beginning, with greater continuity,
                clearer communication, and support that reflects how people actually live.
              </p>
              <ul className="check-list">
                {differentiators.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <p>The most valuable health support is not always the loudest. Often, it is the most thoughtful.</p>
            </div>
          </div>
        </section>

        <section className="section" id="services">
          <div className="container">
            <div className="section-heading reveal" data-reveal="up">
              <p className="eyebrow">What We Do</p>
              <h2>SovereignMD helps simplify parts of healthcare that people are too often left to manage alone.</h2>
            </div>

            <div className="card-grid card-grid-four">
              {whatWeDo.map((item, index) => (
                <article
                  className="feature-card reveal"
                  data-reveal="up"
                  data-reveal-delay={String(120 + index * 80)}
                  key={item.title}
                >
                  <span className="card-index">0{index + 1}</span>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </article>
              ))}
            </div>

            <p className="section-closing reveal" data-reveal="up" data-reveal-delay="340">
              What distinguishes SovereignMD is not simply the presence of services. It is the quality of continuity
              between them.
            </p>
          </div>
        </section>

        <section className="section" id="difference">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">Why SovereignMD Feels Different</p>
              <h2>Support that feels composed, discreet, and consistent.</h2>
              <p>Many health experiences are available in theory, yet difficult to carry in practice.</p>
              <p>People may receive instructions without clarity.</p>
              <p>Information without context.</p>
              <p>Options without continuity.</p>
              <p>Support without steadiness.</p>
            </div>

            <div className="story-panel prose-panel reveal" data-reveal="right" data-reveal-delay="120">
              <p>
                SovereignMD is built around a more realistic understanding of how people actually engage with their
                health.
              </p>
              <p>People are more likely to follow through when the path feels manageable.</p>
              <p>Families participate more meaningfully when communication is clear.</p>
              <p>Concerns are raised earlier when the experience feels respectful rather than intimidating.</p>
              <p>And trust grows when support feels composed, discreet, and consistent.</p>
            </div>
          </div>
        </section>

        <section className="section" id="how-it-works">
          <div className="container">
            <div className="section-heading reveal" data-reveal="up">
              <p className="eyebrow">How It Works</p>
              <h2>Better continuity, more confidence, and a more practical next step.</h2>
            </div>

            <div className="timeline">
              {steps.map((step, index) => (
                <article
                  className="timeline-step reveal"
                  data-reveal="up"
                  data-reveal-delay={String(120 + index * 90)}
                  key={step.title}
                >
                  <div className="timeline-marker">{index + 1}</div>
                  <div>
                    <h3>{step.title}</h3>
                    <p>{step.text}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="clarity">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">Clarity Between Visits</p>
              <h2>Important health changes do not always happen all at once.</h2>
              <p>
                In many cases, they develop gradually, through patterns that are easy to miss when life is busy and
                information is scattered.
              </p>
              <p>
                For some individuals, a more connected experience may include simple health monitoring support as part
                of a broader continuity-focused model.
              </p>
              <p>
                The purpose is not to create noise or unnecessary alarm. It is to make it easier to notice meaningful
                changes, improve follow-through, and reduce avoidable gaps over time.
              </p>
            </div>

            <div className="story-panel prose-panel reveal" data-reveal="right" data-reveal-delay="120">
              <p>Just as important is making information usable.</p>
              <p>
                People are often expected to remember symptoms, medications, appointments, changes, and questions
                under pressure. That is neither realistic nor fair.
              </p>
              <p>
                SovereignMD places strong emphasis on clear health summaries because being able to tell your story
                clearly can shape the quality of the care experience in meaningful ways.
              </p>
              <p>A good summary does more than save time. It reduces stress. It improves continuity.</p>
            </div>
          </div>
        </section>

        <section className="section" id="ecosystem">
          <div className="container">
            <div className="story-panel prose-panel reveal" data-reveal="up">
              <p className="eyebrow">A Broader Support Ecosystem</p>
              <h2>A carefully structured ecosystem of services, support pathways, and organizational tools.</h2>
              <p>
                SovereignMD is designed to support a growing range of health and care-related needs through a carefully
                structured ecosystem of services, support pathways, and organizational tools.
              </p>
              <p>
                Depending on individual circumstances and pathway availability, this may include elements of preventive
                support, continuity services, monitoring-related workflows, care preparation, diagnostics coordination,
                sleep-related pathways, and other select support experiences that help people move through healthcare
                with greater clarity and less friction.
              </p>
              <p>
                We are continuing to expand thoughtfully, with additional surrounding services and capabilities being
                added over time where they meaningfully improve the patient and family experience.
              </p>
              <p className="small-note">
                Service availability may vary by pathway, setting, and clinical appropriateness.
              </p>
            </div>
          </div>
        </section>

        <section className="section" id="real-life">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">Designed for Real Life</p>
              <h2>Healthcare does not happen in isolation.</h2>
              <p>A spouse notices a pattern. A daughter remembers the missing detail. A son manages the appointments.</p>
              <p>
                A caregiver carries information no one else wrote down. An elder may minimize what matters. A family
                may delay getting help simply because the system feels difficult to approach.
              </p>
              <p>SovereignMD is built with these realities in mind.</p>
            </div>

            <div className="story-panel prose-panel reveal" data-reveal="right" data-reveal-delay="120">
              <p>
                We believe support should reflect how people actually live, how decisions are actually made, and how
                much emotional weight families often carry while trying to do the right thing.
              </p>
              <p>
                We are equally committed to preserving dignity. Support should never feel theatrical, performative, or
                needlessly exposing.
              </p>
              <p>
                Whether someone begins with a simple plan or receives added support through a broader community-minded
                framework, our standard remains the same: the experience should feel respectful, private, and
                well-considered.
              </p>
            </div>
          </div>
        </section>

        <section className="section" id="membership">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">Membership</p>
              <h2>Preventive health support that is accessible, organized, and easier to sustain over time.</h2>
              <p>
                Our membership model is designed to make preventive health support more accessible, more organized, and
                easier to sustain over time.
              </p>
              <p>
                Membership is not designed as a flood of features for the sake of marketing. It is designed to create
                steadiness, continuity, and a more practical way to stay connected to your health over time.
              </p>
              <p className="small-note">
                Community support allocations are subject to program availability, eligibility considerations, and
                long-term sustainability.
              </p>
            </div>

            <article className="membership-card reveal" data-reveal="right" data-reveal-delay="120">
              <p className="eyebrow">SovereignMD Membership</p>
              <h3>$49.99 / month</h3>
              <p className="membership-summary">
                A continuity-focused membership for individuals and families seeking a more organized, supportive
                approach to health.
              </p>
              <ul className="check-list light">
                {membershipBenefits.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <p className="membership-note">
                $1 from every active membership is set aside to help extend membership access to people in need.
              </p>
              <p className="membership-note">
                As the membership base grows sustainably over time, SovereignMD may use these funds to help cover up
                to 50% of membership costs for qualifying individuals, based on program availability, sustainability,
                and the strength and duration of the supporting membership base.
              </p>
              <p className="membership-note">Support is extended in a way that protects privacy and preserves dignity.</p>
              <a className="button button-primary" href="#contact">
                Join Membership
              </a>
            </article>
          </div>
        </section>

        <section className="section" id="partners">
          <div className="container story-grid">
            <div className="story-panel prose-panel reveal" data-reveal="left">
              <p className="eyebrow">For Clinics, Physicians, and Health Organizations</p>
              <h2>Built to work thoughtfully with care environments.</h2>
              <p>
                SovereignMD also works alongside clinics, physicians, and health organizations where added structure,
                continuity support, and patient-facing coordination can strengthen the overall care experience.
              </p>
              <p>
                Our collaborative approach is designed to fit thoughtfully around existing care environments, including
                private physician practices, solo and group practices, community-based clinics, and select
                institutional settings.
              </p>
            </div>

            <div className="story-panel prose-panel reveal" data-reveal="right" data-reveal-delay="120">
              <p>
                Depending on context and need, this may include support around patient preparation,
                continuity-related workflows, care pathway organization, and select service extensions that help
                practices and organizations deliver a more connected experience.
              </p>
              <p>
                We believe the strongest partnerships are the ones that are operationally useful, clinically
                respectful, and carefully aligned with how care is already being delivered.
              </p>
              <p>
                We are deliberate in how we build these relationships, with a focus on discretion, fit, and long-term
                value rather than one-size-fits-all arrangements.
              </p>
              <a className="text-link" href="#contact">
                Explore Partnerships
              </a>
            </div>
          </div>
        </section>

        <section className="section" id="library">
          <div className="container">
            <div className="section-heading reveal" data-reveal="up">
              <p className="eyebrow">Library</p>
              <h2>A quieter place for thoughtful perspectives on prevention, continuity, and patient experience.</h2>
              <p className="section-intro">
                A quieter place for thoughtful perspectives on prevention, continuity, patient experience,
                family-centered care, and the changing shape of modern healthcare support.
              </p>
            </div>

            <div className="card-grid">
              {libraryTiles.map((tile, index) => (
                <article
                  className="feature-card reveal"
                  data-reveal="up"
                  data-reveal-delay={String(100 + index * 70)}
                  key={tile.title}
                >
                  <h3>{tile.title}</h3>
                  <p>{tile.text}</p>
                </article>
              ))}
            </div>

            <div className="section-actions reveal" data-reveal="up" data-reveal-delay="260">
              <a className="button button-ghost" href="#contact">
                Visit the Library
              </a>
            </div>
          </div>
        </section>

        <section className="section" id="values">
          <div className="container">
            <div className="section-heading reveal" data-reveal="up">
              <p className="eyebrow">Our Values</p>
              <h2>Clarity, continuity, dignity, trust, and thoughtful access.</h2>
            </div>

            <div className="card-grid card-grid-three">
              {values.map((item, index) => (
                <article
                  className="feature-card reveal"
                  data-reveal="up"
                  data-reveal-delay={String(100 + index * 60)}
                  key={item.title}
                >
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="approach">
          <div className="container">
            <div className="story-panel prose-panel reveal" data-reveal="up">
              <p className="eyebrow">A Thoughtful Approach</p>
              <h2>Organization, continuity-focused guidance, and carefully structured service coordination.</h2>
              <p>
                SovereignMD is designed to support the health experience through organization, continuity-focused
                guidance, preventive support, and carefully structured service coordination.
              </p>
              <p>
                Where clinical care is needed, it is provided through appropriate licensed medical pathways. This
                allows us to remain focused on an area that is often overlooked but deeply important: helping people
                feel more prepared, more supported, and less alone in navigating what comes next.
              </p>
              <p>
                We also believe privacy is not a marketing phrase. It is part of the trust people place in us, and it
                should be treated accordingly.
              </p>
            </div>
          </div>
        </section>

        <section className="section cta-section" id="contact">
          <div className="container cta-card reveal" data-reveal="up">
            <div>
              <p className="eyebrow">A Better Experience of Care</p>
              <h2>More thoughtful. More steady. More aligned with the way people actually live.</h2>
              <p>
                SovereignMD exists to make healthcare feel more connected, more composed, and more human from the
                beginning. Not louder. Not more theatrical. Not more complicated than it needs to be. Just clearer.
              </p>
            </div>
            <div className="cta-actions">
              <a className="button button-primary" href="#membership">
                Get Started
              </a>
              <a className="button button-ghost" href="mailto:hello@sovereignmd.com">
                Contact Us
              </a>
            </div>
          </div>
        </section>

        <footer className="site-footer">
          <div className="container footer-grid">
            <div className="footer-brand reveal" data-reveal="up">
              <a className="brand" href="#top">
                SovereignMD
              </a>
              <p>
                SovereignMD is a preventive health and care-support platform built to bring greater clarity,
                continuity, and dignity to the healthcare experience for individuals, families, and care partners.
              </p>
              <p>
                SovereignMD works with individuals, families, and select care environments, including physician
                practices, clinics, and health organizations, through carefully structured support pathways.
              </p>
            </div>

            <div className="footer-nav reveal" data-reveal="up" data-reveal-delay="120">
              {navigation.map((item) => (
                <a key={item.label} href={item.href}>
                  {item.label}
                </a>
              ))}
              <a href="#library">Library</a>
              {legalLinks.map((link) => (
                <a key={link.href} href={link.href}>
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          <div className="container footer-meta reveal" data-reveal="up" data-reveal-delay="180">
            <p>
              Support services are designed to strengthen organization, continuity, and access. Clinical care is
              provided through appropriate licensed medical pathways where applicable.
            </p>
            <p>© SovereignMD. All rights reserved.</p>
          </div>
        </footer>
      </main>
      <AnimationBootstrap />
    </>
  );
}
