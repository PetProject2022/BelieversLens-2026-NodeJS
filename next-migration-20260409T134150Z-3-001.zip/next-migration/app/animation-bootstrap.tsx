"use client";

import { useEffect } from "react";

type RevealMode = "up" | "left" | "right" | "zoom";

const hiddenTransforms: Record<RevealMode, string> = {
  up: "translate3d(0, 36px, 0)",
  left: "translate3d(-36px, 0, 0)",
  right: "translate3d(36px, 0, 0)",
  zoom: "scale(0.92)",
};

export default function AnimationBootstrap() {
  useEffect(() => {
    const header = document.querySelector<HTMLElement>(".site-header");
    const revealNodes = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    const countNodes = Array.from(document.querySelectorAll<HTMLElement>("[data-count-to]"));
    const parallaxNodes = Array.from(document.querySelectorAll<HTMLElement>("[data-parallax]"));

    revealNodes.forEach((node) => {
      const mode = (node.dataset.reveal as RevealMode | undefined) ?? "up";
      node.style.opacity = "0";
      node.style.transform = hiddenTransforms[mode] ?? hiddenTransforms.up;
    });

    const revealNode = (node: HTMLElement) => {
      const delay = Number(node.dataset.revealDelay ?? "0");
      node.style.transition =
        `opacity 720ms cubic-bezier(0.22, 1, 0.36, 1) ${delay}ms, ` +
        `transform 720ms cubic-bezier(0.22, 1, 0.36, 1) ${delay}ms`;
      node.style.willChange = "opacity, transform";

      window.requestAnimationFrame(() => {
        node.style.opacity = "1";
        node.style.transform = "none";
      });
    };

    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) {
            return;
          }

          revealNode(entry.target as HTMLElement);
          revealObserver.unobserve(entry.target);
        });
      },
      { threshold: 0.16, rootMargin: "0px 0px -8% 0px" }
    );

    revealNodes.forEach((node) => revealObserver.observe(node));

    const playedCounters = new WeakSet<HTMLElement>();
    const countObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) {
            return;
          }

          const node = entry.target as HTMLElement;
          if (playedCounters.has(node)) {
            countObserver.unobserve(node);
            return;
          }

          playedCounters.add(node);
          countObserver.unobserve(node);

          const target = Number(node.dataset.countTo ?? "0");
          const duration = Number(node.dataset.countDuration ?? "1400");
          const start = performance.now();

          const tick = (now: number) => {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            node.textContent = String(Math.round(target * eased));

            if (progress < 1) {
              window.requestAnimationFrame(tick);
            }
          };

          window.requestAnimationFrame(tick);
        });
      },
      { threshold: 0.55 }
    );

    countNodes.forEach((node) => countObserver.observe(node));

    const handleScroll = () => {
      const y = window.scrollY;

      if (header) {
        header.classList.toggle("is-scrolled", y > 24);
      }

      parallaxNodes.forEach((node) => {
        const speed = Number(node.dataset.parallax ?? "0.1");
        node.style.transform = `translate3d(0, ${y * speed}px, 0)`;
      });
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      revealObserver.disconnect();
      countObserver.disconnect();
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return null;
}
