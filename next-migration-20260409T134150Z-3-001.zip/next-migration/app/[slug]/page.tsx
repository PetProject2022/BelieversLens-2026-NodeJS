import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { legalLinks, legalPages, legalSlugs } from "../legal-content";

type PageProps = {
  params: {
    slug: string;
  };
};

export function generateStaticParams() {
  return legalSlugs.map((slug) => ({ slug }));
}

export function generateMetadata({ params }: PageProps): Metadata {
  const doc = legalPages[params.slug];

  if (!doc) {
    return {};
  }

  return {
    title: `${doc.title} | SovereignMD`,
    description: `${doc.title} for SovereignMD. Effective ${doc.effectiveDate}.`,
  };
}

export default function LegalPage({ params }: PageProps) {
  const doc = legalPages[params.slug];

  if (!doc) {
    notFound();
  }

  return (
    <main className="site-shell legal-shell">
      <div className="page-aura" aria-hidden="true" />

      <div className="announcement-bar">
        <div className="container">
          <p>Important documents for privacy, consent, billing, and membership terms.</p>
        </div>
      </div>

      <header className="site-header legal-header">
        <div className="container nav-row">
          <Link className="brand" href="/">
            SovereignMD
          </Link>

          <nav className="nav-links legal-links" aria-label="Legal pages">
            {legalLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                {link.label}
              </Link>
            ))}
          </nav>

          <Link className="button button-secondary header-cta" href="/">
            Back Home
          </Link>
        </div>
      </header>

      <section className="legal-hero">
        <div className="container">
          <div className="legal-card">
            <p className="eyebrow">Legal Page</p>
            <h1 className="legal-title">{doc.title}</h1>
            <div className="legal-meta">
              <span>URL: /{doc.slug}</span>
              <span>Effective Date: {doc.effectiveDate}</span>
            </div>
            {doc.intro?.map((paragraph) => (
              <p key={paragraph} className="legal-intro">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </section>

      <section className="legal-content-section">
        <div className="container legal-layout">
          <aside className="legal-sidebar">
            <div className="legal-sidebar-card">
              <p className="eyebrow">On This Page</p>
              <nav className="legal-sidebar-nav">
                {doc.sections.map((section, index) => (
                  <a key={section.heading} href={`#section-${index + 1}`}>
                    {section.heading}
                  </a>
                ))}
              </nav>
            </div>
          </aside>

          <article className="legal-body">
            {doc.sections.map((section, index) => (
              <section className="legal-section" id={`section-${index + 1}`} key={section.heading}>
                <h2>{section.heading}</h2>
                {section.paragraphs?.map((paragraph) => (
                  <p key={paragraph}>{paragraph}</p>
                ))}
                {section.bullets?.length ? (
                  <ul className="legal-list">
                    {section.bullets.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                ) : null}
              </section>
            ))}

            {doc.acknowledgment ? (
              <div className="legal-acknowledgment">
                <p>{doc.acknowledgment}</p>
              </div>
            ) : null}
          </article>
        </div>
      </section>

      <footer className="site-footer legal-footer">
        <div className="container footer-grid">
          <div className="footer-brand">
            <Link className="brand" href="/">
              SovereignMD
            </Link>
            <p>
              SovereignMD is a preventive health and care-support platform built to bring greater clarity, continuity,
              and dignity to the healthcare experience for individuals, families, and care partners.
            </p>
          </div>

          <div className="footer-nav">
            <Link href="/">Home</Link>
            {legalLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </footer>
    </main>
  );
}
