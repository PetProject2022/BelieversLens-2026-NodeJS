export type LegalSection = {
  heading: string;
  paragraphs?: string[];
  bullets?: string[];
};

export type LegalDocument = {
  slug: string;
  navLabel: string;
  title: string;
  effectiveDate: string;
  intro?: string[];
  sections: LegalSection[];
  acknowledgment?: string;
};

export const legalLinks = [
  { label: "Notice of Privacy Practices", href: "/notice-of-privacy-practices" },
  { label: "Privacy Policy", href: "/privacy-policy" },
  { label: "Terms of Use & Subscription Terms", href: "/terms" },
  { label: "Financial Policy", href: "/financial-policy" },
  { label: "Telehealth Consent", href: "/telehealth-consent" },
  { label: "Device, Monitoring & Enrollment Consent", href: "/device-monitoring-consent" },
] as const;

export const legalPages: Record<string, LegalDocument> = {
  "notice-of-privacy-practices": {
    slug: "notice-of-privacy-practices",
    navLabel: "Notice of Privacy Practices",
    title: "Notice of Privacy Practices",
    effectiveDate: "03/21/2026",
    intro: [
      "This Notice describes how medical and health information about you may be used and disclosed and how you can get access to that information. Please review it carefully.",
      "Sovereign Wave LLC d/b/a SovereignMD (“SovereignMD,” “we,” “us,” or “our”) is committed to protecting the privacy of your health information. This Notice explains how we may use and disclose your protected health information (“PHI”) when applicable, and it describes your rights regarding that information.",
      "This Notice applies to protected health information created, received, maintained, or transmitted in connection with healthcare services, telehealth services, remote monitoring programs, care coordination, summaries, and related support functions, to the extent applicable law requires.",
      "SovereignMD may operate in different roles depending on the service involved. In some circumstances, clinical services are provided by licensed physicians, nurse practitioners, physician assistants, clinics, hospitals, or other independent provider entities. SovereignMD may also provide non-clinical support services such as intake support, scheduling, care coordination, device logistics, patient summaries, communications support, operational workflows, and administrative services. Where required by law, we handle protected health information in accordance with federal and applicable state privacy requirements.",
    ],
    sections: [
      {
        heading: "Your Rights",
        paragraphs: ["You may have the right to:"],
        bullets: [
          "inspect or receive a copy of certain health and billing records we maintain about you;",
          "ask us to correct or amend certain information if you believe it is incomplete or inaccurate;",
          "request confidential communications in a particular way or at a particular location;",
          "request restrictions on certain uses or disclosures;",
          "request an accounting of certain disclosures;",
          "obtain a paper or electronic copy of this Notice at any time; and",
          "file a complaint with us or with the U.S. Department of Health and Human Services if you believe your privacy rights have been violated.",
        ],
      },
      {
        heading: "Exercising Your Rights",
        paragraphs: ["To exercise any of these rights, contact us using the information at the end of this Notice."],
      },
      {
        heading: "For Treatment",
        paragraphs: [
          "We may use and disclose your health information to provide, coordinate, or support your care and to share information with clinicians, partner providers, pharmacies, laboratories, imaging centers, remote monitoring teams, and other healthcare professionals involved in your care.",
        ],
      },
      {
        heading: "For Payment",
        paragraphs: [
          "We may use and disclose your health information to bill for services, collect payment, verify eligibility, respond to payor requests, process claims, coordinate benefits, and manage accounts.",
        ],
      },
      {
        heading: "For Healthcare Operations",
        paragraphs: [
          "We may use and disclose your health information for healthcare operations, including quality review, compliance, auditing, care coordination, training, credentialing support, service improvement, customer support, and business administration.",
        ],
      },
      {
        heading: "Appointment Reminders and Service Communications",
        paragraphs: [
          "We may contact you regarding appointments, telehealth sessions, onboarding, device setup, follow-up care, monitoring support, billing matters, and other service-related communications.",
        ],
      },
      {
        heading: "Individuals Involved in Your Care",
        paragraphs: [
          "Unless you object, or where otherwise permitted by law, we may share relevant information with family members, caregivers, guardians, or personal representatives involved in your care or payment for care.",
        ],
      },
      {
        heading: "Required by Law",
        paragraphs: [
          "We may use or disclose your information when required by federal, state, or local law, court order, subpoena, legal process, public health reporting obligations, or lawful government request.",
        ],
      },
      {
        heading: "Public Health and Safety",
        paragraphs: [
          "We may disclose information when legally permitted or required for public health activities, abuse or neglect reporting, health oversight, or to prevent or lessen a serious threat to health or safety.",
        ],
      },
      {
        heading: "Business Associates and Service Providers",
        paragraphs: [
          "We may disclose information to vendors and contractors that support our operations, including telehealth platforms, secure communication vendors, cloud hosting providers, billing support vendors, device logistics vendors, and related service providers, where appropriate safeguards are in place.",
        ],
      },
      {
        heading: "Uses and Disclosures Requiring Authorization",
        paragraphs: [
          "Except where otherwise allowed by law, we will obtain your written authorization before using or disclosing your health information for purposes that require authorization. You may revoke an authorization in writing, except to the extent action has already been taken in reliance on it.",
        ],
      },
      {
        heading: "Specially Protected Information",
        paragraphs: [
          "Certain categories of information may receive additional protection under federal or state law, including substance use disorder treatment records, certain mental health records, HIV-related information, genetic information, reproductive health information, and records involving minors. Where those laws apply, we will follow the additional protections required.",
        ],
      },
      {
        heading: "Our Duties",
        paragraphs: ["We are required by law, where applicable, to:"],
        bullets: [
          "maintain the privacy of protected health information;",
          "provide you with this Notice of our legal duties and privacy practices;",
          "follow the terms of the Notice currently in effect; and",
          "provide notice as required by law if a reportable breach of unsecured protected health information occurs.",
        ],
      },
      {
        heading: "Complaints",
        paragraphs: [
          "If you believe your privacy rights have been violated, you may file a complaint with us by contacting our Privacy Officer. You may also file a complaint with the U.S. Department of Health and Human Services, Office for Civil Rights. We will not retaliate against you for filing a complaint.",
        ],
      },
      {
        heading: "Changes to This Notice",
        paragraphs: [
          "We may change this Notice from time to time. Any updated Notice will be posted on this website with a revised effective date and will apply as permitted by law.",
        ],
      },
      {
        heading: "Contact Information",
        paragraphs: [
          "Privacy Officer",
          "Sovereign Wave LLC d/b/a SovereignMD",
          "7901 4th St N, STE 300, St. Pete, 33702",
          "info@sovmd.com",
        ],
      },
    ],
    acknowledgment: "I acknowledge and agree to the Notice of Privacy Practices Policy.",
  },
  "privacy-policy": {
    slug: "privacy-policy",
    navLabel: "Privacy Policy",
    title: "Privacy Policy",
    effectiveDate: "03/21/2026",
    intro: [
      "Sovereign Wave LLC d/b/a SovereignMD (“SovereignMD,” “we,” “us,” or “our”) respects your privacy and is committed to handling your information with care, discretion, and transparency.",
      "This Privacy Policy explains how we collect, use, store, protect, and disclose personal information through our website, landing pages, forms, events, communications, memberships, applications, digital services, and related operations.",
      "This Privacy Policy is separate from our Notice of Privacy Practices. Our Notice of Privacy Practices applies where protected health information is governed by healthcare privacy law.",
    ],
    sections: [
      {
        heading: "Information We Collect",
        paragraphs: ["We may collect information that you provide directly, including:"],
        bullets: [
          "name;",
          "date of birth;",
          "phone number;",
          "email address;",
          "mailing address;",
          "preferred language;",
          "emergency contact information;",
          "dependent or household enrollment information;",
          "billing and payment details;",
          "insurance-related information;",
          "intake responses, forms, and questionnaires;",
          "messages, requests, support inquiries, and survey responses;",
          "event registration information;",
          "sponsorship or subsidy request information;",
          "device enrollment and shipping details; and",
          "health-related information you choose to provide in connection with services.",
        ],
      },
      {
        heading: "Automatically Collected Data",
        paragraphs: ["We may also collect information automatically through our website and digital tools, including:"],
        bullets: [
          "IP address;",
          "device type;",
          "browser type;",
          "operating system;",
          "pages viewed;",
          "referral source;",
          "session activity;",
          "approximate geolocation derived from IP;",
          "cookies and similar technologies; and",
          "security and diagnostic log data.",
        ],
      },
      {
        heading: "Other Sources",
        paragraphs: [
          "We may also receive information from other sources, such as partner providers, laboratories, pharmacies, device vendors, payment processors, caregivers, referral partners, and service providers, where permitted.",
        ],
      },
      {
        heading: "How We Use Information",
        bullets: [
          "operate, maintain, and improve our services;",
          "process enrollments, memberships, subscriptions, and account administration;",
          "coordinate care access, device setup, scheduling, and follow-up;",
          "support telehealth, remote monitoring, summaries, and related service workflows;",
          "communicate with you about services, appointments, onboarding, billing, and support;",
          "personalize user experience and improve service quality;",
          "verify identity and prevent fraud or misuse;",
          "maintain records, logs, and compliance documentation;",
          "respond to legal requests and fulfill legal obligations; and",
          "create de-identified or aggregated information for quality, analytics, service development, and operational planning, where permitted by law.",
        ],
      },
      {
        heading: "Communications",
        paragraphs: [
          "By providing your contact information, you agree that we and our service providers may contact you by phone, email, portal message, or text regarding appointments, account matters, device setup, billing, support, enrollment updates, and other service-related matters.",
          "Where promotional or marketing communications require consent, we will seek that consent where required by law. You may opt out of non-essential promotional communications using the instructions provided in the message or by contacting us.",
          "Message and data rates may apply.",
        ],
      },
      {
        heading: "Cookies and Similar Technologies",
        paragraphs: ["We may use cookies, pixels, analytics tools, and similar technologies to:"],
        bullets: [
          "keep the website functioning properly;",
          "remember preferences;",
          "understand site traffic and usage;",
          "improve performance and user experience;",
          "support security and fraud prevention; and",
          "help us understand which pages and communications are most useful.",
        ],
      },
      {
        heading: "Managing Cookies",
        paragraphs: [
          "You may be able to manage cookies through your browser settings, although some website features may not work properly if cookies are disabled.",
        ],
      },
      {
        heading: "How We Share Information",
        paragraphs: [
          "We do not sell your personal information for money. We do not sell patient health data.",
          "We may disclose information:",
        ],
        bullets: [
          "to licensed providers, clinics, hospitals, laboratories, pharmacies, and other care partners involved in requested services;",
          "to vendors and contractors who help us operate our services, including telehealth vendors, hosting providers, secure messaging platforms, workflow vendors, payment processors, shipping providers, device vendors, and analytics providers;",
          "to professional advisors, auditors, and regulators;",
          "in response to lawful legal process or government request;",
          "to protect rights, safety, property, and security;",
          "in connection with a merger, financing, reorganization, or sale of assets, subject to appropriate safeguards; and",
          "in de-identified or aggregated form.",
        ],
      },
      {
        heading: "Data Retention",
        paragraphs: [
          "We retain personal information for as long as reasonably necessary for the purposes described in this Privacy Policy, for legal and compliance obligations, for dispute resolution, for business continuity, and for operational recordkeeping.",
          "Retention periods may vary depending on the type of information, the service involved, and applicable law.",
        ],
      },
      {
        heading: "Security",
        paragraphs: [
          "We use reasonable administrative, technical, and physical safeguards designed to protect personal information and health-related information from unauthorized access, disclosure, alteration, or destruction. These safeguards may include encryption, access controls, authentication measures, logging, vendor diligence, workforce training, and incident response procedures.",
          "No method of transmission over the internet or method of storage is completely secure, and we cannot guarantee absolute security.",
        ],
      },
      {
        heading: "Children and Dependents",
        paragraphs: [
          "We do not knowingly collect personal information directly from children in violation of applicable law. Enrollment for minors or dependents must be completed by a parent, guardian, or other legally authorized representative where required.",
        ],
      },
      {
        heading: "State-Specific Rights",
        paragraphs: [
          "Depending on your state of residence and the type of information involved, you may have rights regarding access, correction, deletion, appeal, or other privacy requests. We will honor applicable rights requests to the extent required by law and appropriate to our role.",
        ],
      },
      {
        heading: "Changes to This Privacy Policy",
        paragraphs: [
          "We may update this Privacy Policy from time to time. The updated version will be posted on this page with a revised effective date.",
        ],
      },
      {
        heading: "Contact Us",
        paragraphs: [
          "Sovereign Wave LLC d/b/a SovereignMD",
          "7901, 4th st N, STE 300, St. Petersburg 33702",
          "info@sovmd.com",
        ],
      },
    ],
    acknowledgment: "I acknowledge and agree to the Privacy & Data Policy.",
  },
  terms: {
    slug: "terms",
    navLabel: "Terms of Use & Subscription Terms",
    title: "Terms of Use & Subscription Terms",
    effectiveDate: "03/21/2026",
    intro: [
      "These Terms of Use & Subscription Terms (“Terms”) govern your access to and use of the SovereignMD website, digital services, memberships, recurring programs, and related offerings.",
      "By accessing this website, creating an account, enrolling in a service, purchasing a membership, or otherwise using our services, you agree to these Terms.",
    ],
    sections: [
      {
        heading: "Eligibility",
        paragraphs: [
          "You must be legally capable of entering into a binding agreement to use our services. If you enroll a dependent, household member, or another person, you represent that you are authorized to do so and to provide the necessary information and consents.",
        ],
      },
      {
        heading: "Important Service Clarifications",
        paragraphs: [
          "SovereignMD may provide non-clinical support services such as coordination, navigation, intake support, scheduling, summaries, device logistics, communications support, and related administrative functions.",
          "Clinical diagnosis, treatment, prescribing, interpretation of test results, and other medical decision-making may be performed only by licensed clinicians or provider entities acting within applicable law.",
        ],
      },
      {
        heading: "Not Emergency Services",
        paragraphs: [
          "Our website, messages, subscriptions, monitoring support, and telehealth coordination tools are not emergency services. If you think you are experiencing a medical emergency, call 911 immediately or go to the nearest emergency room.",
        ],
      },
      {
        heading: "Not Insurance",
        paragraphs: [
          "SovereignMD memberships, subscriptions, and support programs are not health insurance, do not replace health insurance, and do not guarantee reimbursement, coverage, or availability of any specific clinical service, device, prescription, or provider.",
        ],
      },
      {
        heading: "Memberships and Recurring Programs",
        paragraphs: [
          "Certain services may be offered on a recurring basis, including memberships, monitoring support programs, device-supported programs, or household support plans.",
          "Your plan details, pricing, included services, billing frequency, and any plan-specific limitations will be disclosed at enrollment or in your plan materials.",
        ],
      },
      {
        heading: "Recurring Billing Authorization",
        paragraphs: [
          "By enrolling in a recurring plan, you authorize us and our payment processors to charge your designated payment method on a recurring basis according to the billing cycle selected at enrollment, until you cancel in accordance with these Terms.",
        ],
      },
      {
        heading: "Cancellation",
        paragraphs: [
          "You may cancel a recurring plan using the cancellation method made available in your account, enrollment confirmation, or support instructions.",
          "Unless otherwise stated in writing or required by law:",
        ],
        bullets: [
          "cancellation stops future renewal charges after the current billing period or the next effective cancellation date disclosed at sign-up;",
          "charges already processed for the current active billing period are generally not refunded; and",
          "completed services, activated services, and earned fees are generally non-refundable.",
        ],
      },
      {
        heading: "Promotions and Introductory Offers",
        paragraphs: [
          "Promotional pricing, event-based offers, sponsored periods, discounts, free trials, first-month offers, or subsidized access are subject to the specific written terms of that offer and may automatically convert to a paid plan unless canceled in accordance with the disclosed offer terms.",
        ],
      },
      {
        heading: "Plan Changes",
        paragraphs: [
          "We may update pricing, plan features, technology platforms, vendor relationships, workflows, or service availability prospectively. Material changes will be communicated as required by law.",
        ],
      },
      {
        heading: "Suspension or Termination",
        paragraphs: ["We may suspend or terminate access or enrollment for reasons including:"],
        bullets: [
          "nonpayment;",
          "fraud, abuse, or misuse;",
          "unsafe or unlawful conduct;",
          "violation of these Terms;",
          "operational or legal inability to continue the service; or",
          "ineligibility for a particular program.",
        ],
      },
      {
        heading: "Notice of Suspension or Termination",
        paragraphs: ["Where reasonably practicable, we will provide notice."],
      },
      {
        heading: "Intellectual Property",
        paragraphs: [
          "All website content, branding, text, graphics, logos, designs, and related materials are owned by or licensed to SovereignMD and are protected by applicable law. You may not reproduce, distribute, modify, exploit, or create derivative works from our content without prior written permission, except as allowed by law.",
        ],
      },
      {
        heading: "Third-Party Services",
        paragraphs: [
          "Our services may involve or link to third-party platforms, clinicians, vendors, payment processors, telehealth systems, device vendors, or service providers. We are not responsible for the separate terms, privacy practices, or independent decisions of third parties, except to the extent required by law.",
        ],
      },
      {
        heading: "Disclaimer of Warranties",
        paragraphs: [
          "To the maximum extent permitted by law, the website and non-clinical digital services are provided on an “as is” and “as available” basis, without warranties of any kind, express or implied.",
        ],
      },
      {
        heading: "Limitation of Liability",
        paragraphs: [
          "To the fullest extent permitted by law, SovereignMD shall not be liable for indirect, incidental, special, consequential, or punitive damages arising out of or relating to the use of the website or non-clinical services. Nothing in these Terms is intended to limit liability where such limitation is prohibited by law.",
        ],
      },
      {
        heading: "Governing Law",
        paragraphs: [
          "These Terms are governed by the laws of the State of Florida, except where another state’s mandatory consumer protection, healthcare, privacy, or telehealth law applies because of the user’s location or the location where care is rendered.",
        ],
      },
      {
        heading: "Contact",
        paragraphs: ["Sovereign Wave LLC d/b/a SovereignMD", "info@sovmed.com"],
      },
    ],
    acknowledgment: "I acknowledge the notification of Terms of use and Subscriptions Policy.",
  },
  "financial-policy": {
    slug: "financial-policy",
    navLabel: "Financial Policy",
    title: "Financial Policy",
    effectiveDate: "03/21/2026",
    intro: [
      "SovereignMD is committed to clear, respectful, and transparent financial practices.",
      "This Financial Policy explains how billing, payments, memberships, device fees, telehealth-related charges, financing, refunds, and related financial matters are handled.",
    ],
    sections: [
      {
        heading: "Separate Billing Entities",
        paragraphs: ["Depending on the service involved, charges may come from:"],
        bullets: [
          "SovereignMD for memberships, administrative services, coordination support, summaries, device logistics, monitoring support programs, or other non-clinical offerings;",
          "a licensed clinician, clinic, hospital, or provider group for professional medical services;",
          "a laboratory, imaging center, pharmacy, device vendor, financing provider, or other third party for separate products or services.",
        ],
      },
      {
        heading: "Separate Bills",
        paragraphs: ["Separate bills may apply."],
      },
      {
        heading: "Not Insurance",
        paragraphs: [
          "Memberships, subscriptions, support programs, and direct-pay offerings through SovereignMD are not insurance and do not constitute a health plan.",
        ],
      },
      {
        heading: "Self-Pay and Good Faith Estimates",
        paragraphs: [
          "If you are uninsured or elect not to use insurance for applicable scheduled healthcare items or services, you may have the right to receive a Good Faith Estimate of expected charges under federal law. A Good Faith Estimate is an estimate only. Actual charges may vary based on clinical needs, changes in services, complications, or information not known at the time the estimate is prepared.",
        ],
      },
      {
        heading: "Insurance",
        paragraphs: [
          "If insurance is accepted for a clinical service, coverage, eligibility, prior authorization, deductibles, co-insurance, co-payments, exclusions, medical necessity decisions, and claims outcomes remain subject to the terms of the applicable insurance plan and the billing practices of the responsible provider or entity.",
          "We do not guarantee insurance coverage or reimbursement unless expressly stated in writing by the responsible billing entity.",
        ],
      },
      {
        heading: "Payment Methods",
        paragraphs: [
          "You authorize us and our authorized payment processors to charge your designated payment method for amounts due, including recurring charges, authorized one-time charges, shipping charges, taxes where applicable, replacement fees, and other agreed amounts.",
          "If payment fails, we may retry the payment, request an updated payment method, suspend service, or terminate enrollment consistent with applicable law and plan terms.",
        ],
      },
      {
        heading: "Membership and Subscription Charges",
        paragraphs: [
          "Membership fees and recurring program charges are generally billed in advance according to the selected billing cycle.",
          "Membership fees pay for the access, support, pricing privileges, coordination services, or other features described in your plan materials.",
        ],
      },
      {
        heading: "Device Fees and Program Charges",
        paragraphs: ["Certain programs may include:"],
        bullets: [
          "enrollment fees;",
          "setup fees;",
          "shipping fees;",
          "monthly support or monitoring fees;",
          "deposits;",
          "replacement charges for lost, damaged, or unreturned equipment;",
          "clinician fees; and",
          "third-party vendor charges.",
        ],
      },
      {
        heading: "Program Charge Disclosure",
        paragraphs: ["These will be disclosed at enrollment or in related program materials."],
      },
      {
        heading: "Financing and Pay-Later Services",
        paragraphs: [
          "If financing, installment plans, or pay-later services are offered, they may be provided by a separate financing partner and subject to separate approval, underwriting, and terms. SovereignMD is not the lender unless expressly stated otherwise.",
        ],
      },
      {
        heading: "Refunds",
        paragraphs: ["Except where required by law or expressly stated otherwise in writing:"],
        bullets: [
          "completed clinical services are non-refundable;",
          "completed administrative or coordination services are non-refundable;",
          "activated, assigned, used, or opened devices may be non-refundable;",
          "earned membership charges for the current billing period are generally non-refundable; and",
          "unused future prepaid recurring periods may be handled according to the applicable cancellation or refund terms disclosed at enrollment.",
        ],
      },
      {
        heading: "Refund Method",
        paragraphs: ["Approved refunds, if any, will generally be issued to the original payment method."],
      },
      {
        heading: "Collections and Past-Due Balances",
        paragraphs: [
          "Past-due balances may result in suspension of services, enrollment hold, collection efforts, or referral to a collection agency, where permitted by law. You agree to pay lawful collection costs and fees to the extent permitted by contract and law.",
        ],
      },
      {
        heading: "Financial Hardship and Subsidy Review",
        paragraphs: [
          "In appropriate cases, SovereignMD may offer hardship review, sponsorship review, subsidy review, or discretionary payment accommodations. These are case-specific, voluntary, and do not create an entitlement to ongoing support unless expressly stated in writing.",
        ],
      },
      {
        heading: "Changes to Charges",
        paragraphs: ["We may update prices, fees, or plan rates prospectively with notice as required by law or contract."],
      },
      {
        heading: "Billing Contact",
        paragraphs: ["Sovereign Wave LLC d/b/a SovereignMD", "info@sovmed.com"],
      },
    ],
    acknowledgment: "I acknowledge and agree to the Terms and Financial Policy.",
  },
  "telehealth-consent": {
    slug: "telehealth-consent",
    navLabel: "Telehealth Consent",
    title: "Telehealth Consent",
    effectiveDate: "03/21/2026",
    intro: [
      "By signing electronically, clicking “I agree,” or otherwise proceeding with a telehealth-enabled program, you acknowledge and agree to the following:",
    ],
    sections: [
      {
        heading: "Nature of Telehealth",
        paragraphs: [
          "Telehealth involves the use of telecommunications technology to provide or support healthcare services. Telehealth may include video visits, audio visits where permitted, secure messaging, asynchronous review of information, image or data transfer, remote monitoring, and related digital communications.",
        ],
      },
      {
        heading: "Licensed Clinical Care",
        paragraphs: [
          "You understand that diagnosis, treatment recommendations, prescribing, test interpretation, and other clinical decisions may be made only by a licensed healthcare professional or provider entity acting within applicable law and scope of practice.",
          "SovereignMD may provide non-clinical support services such as intake assistance, coordination, scheduling, device logistics, summaries, communications support, and administrative workflows.",
        ],
      },
      {
        heading: "Potential Benefits",
        bullets: [
          "improved access to care;",
          "increased convenience;",
          "reduced travel burden;",
          "more timely follow-up;",
          "easier continuity of care; and",
          "support for monitoring and coordination.",
        ],
      },
      {
        heading: "Risks and Limitations",
        paragraphs: ["You understand that telehealth also involves risks and limitations, including:"],
        bullets: [
          "interruptions, delays, or technical failures;",
          "limits on physical examination;",
          "reduced information available compared to in-person care in some circumstances;",
          "privacy and security risks despite reasonable safeguards; and",
          "the possibility that in-person care, testing, or emergency evaluation may still be needed.",
        ],
      },
      {
        heading: "Emergency Situations",
        paragraphs: [
          "Telehealth is not a substitute for emergency care. If you think you may be experiencing a medical emergency, call 911 immediately or go to the nearest emergency room.",
        ],
      },
      {
        heading: "Your Responsibilities",
        paragraphs: ["You agree to:"],
        bullets: [
          "provide accurate and complete information;",
          "participate from a reasonably private and safe setting when possible;",
          "verify your identity and physical location when asked;",
          "use an adequate internet, phone, or device connection where possible;",
          "follow instructions regarding follow-up care, emergency escalation, and device use; and",
          "understand that portal messages, texts, or asynchronous communications may not be reviewed immediately unless expressly stated otherwise.",
        ],
      },
      {
        heading: "Cross-State Location",
        paragraphs: [
          "You understand that telehealth services are governed in part by the laws of the state where you are physically located at the time of service. If you are located outside Florida, services may be limited or unavailable unless the treating clinician is lawfully authorized to provide care in that state. Florida’s telehealth law separately addresses who may provide telehealth and states that telehealth records are confidential medical records.",
        ],
      },
      {
        heading: "Confidentiality and Records",
        paragraphs: [
          "Telehealth encounters may be documented in your medical or service record. Information generated during telehealth will be handled in accordance with applicable privacy and confidentiality laws and our posted privacy notices.",
        ],
      },
      {
        heading: "Voluntary Consent",
        paragraphs: [
          "Telehealth participation is voluntary. You may withdraw your consent to telehealth at any time, although doing so may affect the availability of certain services.",
        ],
      },
      {
        heading: "Acknowledgment",
        paragraphs: ["By accepting this Consent, you acknowledge that:"],
        bullets: [
          "you have read and understood this Telehealth Consent;",
          "you understand the benefits, risks, and limits of telehealth;",
          "you understand the distinction between non-clinical support services and licensed clinical care; and",
          "you consent to receive telehealth-enabled services where appropriate and available.",
        ],
      },
    ],
    acknowledgment: "I consent to telehealth services as described in the Telehealth Consent.",
  },
  "device-monitoring-consent": {
    slug: "device-monitoring-consent",
    navLabel: "Device, Monitoring & Enrollment Consent",
    title: "Device, Monitoring & Enrollment Consent",
    effectiveDate: "03/21/2026",
    intro: [
      "By signing electronically, clicking “I agree,” enrolling in a device-supported program, or accepting device shipment, you acknowledge and agree to the following:",
    ],
    sections: [
      {
        heading: "Program Overview",
        paragraphs: [
          "You may be enrolled in a program that uses one or more devices or digital tools to collect, transmit, or support review of information such as blood pressure, glucose, pulse, weight, sleep-related information, medication adherence information, rhythm-related information, respiratory information, or other health-related data.",
        ],
      },
      {
        heading: "Device Purpose",
        paragraphs: [
          "You understand that the device is a tool to support monitoring, follow-up, summaries, coordination, and related services. The device itself does not replace emergency care, direct clinical judgment, or in-person evaluation when needed.",
        ],
      },
      {
        heading: "No Emergency Monitoring Representation",
        paragraphs: [
          "Unless expressly stated otherwise in writing, this program is not a 24/7 emergency monitoring service, and not every reading, alert, or data transmission is reviewed in real time.",
          "If you feel unwell, believe you are in danger, or think you may be having a medical emergency, call 911 or seek immediate medical care.",
        ],
      },
      {
        heading: "Data Transmission",
        paragraphs: [
          "You understand that data may be transmitted through cellular, Wi-Fi, Bluetooth, portal, application, or vendor-platform connections. Transmission may be delayed, interrupted, incomplete, or unavailable.",
        ],
      },
      {
        heading: "Collection and Review of Monitoring Data",
        paragraphs: [
          "You consent to the collection, transmission, storage, and review of monitoring data by SovereignMD, authorized vendors, participating clinicians, partner providers, and care teams as reasonably necessary to operate the program and as permitted by law.",
        ],
      },
      {
        heading: "Ownership and Return",
        paragraphs: ["Unless expressly stated otherwise in writing:"],
        bullets: [
          "the device may remain the property of SovereignMD, a partner provider, or a third-party vendor;",
          "the device may be loaned, rented, assigned, subsidized, or sold under specific program terms;",
          "you may be responsible for return shipping, non-return, loss, theft, misuse, or damage fees where disclosed at enrollment.",
        ],
      },
      {
        heading: "Ownership Clarification",
        paragraphs: ["If a device is yours to keep, that will be stated in writing."],
      },
      {
        heading: "Your Responsibilities",
        paragraphs: ["You agree to:"],
        bullets: [
          "use the device as instructed;",
          "avoid tampering, resale, reassignment, or misuse;",
          "keep the device reasonably secure;",
          "notify us if the device is lost, stolen, damaged, or malfunctioning;",
          "follow setup and use instructions; and",
          "provide readings or updates as reasonably requested if manual entry is part of the program.",
        ],
      },
      {
        heading: "Clinical and Non-Clinical Roles",
        paragraphs: [
          "You understand that non-clinical staff may help with onboarding, logistics, summaries, reminders, and support, but they do not diagnose, prescribe, or independently make medical treatment decisions unless they are acting in a licensed clinical role under proper authority.",
        ],
      },
      {
        heading: "Fees and Charges",
        paragraphs: ["You understand that the program may involve charges such as:"],
        bullets: [
          "enrollment fees;",
          "recurring monthly fees;",
          "setup fees;",
          "shipping fees;",
          "deposits;",
          "replacement charges;",
          "separate clinical fees; and",
          "vendor-related charges.",
        ],
      },
      {
        heading: "Charge Disclosure",
        paragraphs: ["You agree to the charges disclosed at enrollment."],
      },
      {
        heading: "Sponsored or Subsidized Access",
        paragraphs: [
          "If your device or enrollment is subsidized, sponsored, discounted, donated, or provided through a community or hardship pathway, you understand that eligibility may be limited, continued support may not be guaranteed, and separate financial review terms may apply.",
        ],
      },
      {
        heading: "Withdrawal",
        paragraphs: [
          "You may withdraw from a device or monitoring program at any time by contacting us, but you may remain responsible for earned fees, return obligations, replacement charges, or other agreed charges.",
        ],
      },
      {
        heading: "Acknowledgment",
        paragraphs: ["By accepting this Consent, you acknowledge that:"],
        bullets: [
          "you understand the purpose and limits of the device and monitoring program;",
          "you understand that this is not emergency monitoring unless expressly stated otherwise in writing;",
          "you consent to the collection and handling of monitoring data as described above; and",
          "you agree to comply with the program’s device use and return requirements.",
        ],
      },
    ],
    acknowledgment:
      "I consent to device enrollment, monitoring, and related data handling as described in the Device & Monitoring Consent.",
  },
} as const;

export const legalSlugs = Object.keys(legalPages);
