# Owais Web

This repository contains the Next.js app in `next-migration/`.

## First-time setup

1. Change into the app directory:
   `cd next-migration`
2. Use Node.js 20:
   `nvm use` if you have `nvm`, or install Node 20 manually.
3. Install dependencies:
   `npm install`
4. Start the development server:
   `npm run dev`

## Project location

- App source: `next-migration/`
- Main app README: `next-migration/README.md`
